# from selenium import webdriver
# import time
# chromedriver_location = "C:/Users/jayant/Downloads/chromedriver"
# driver = webdriver.Chrome(chromedriver_location)
# driver.get('https://latticeinnovations.greythr.com')

import os,sys
import time
from selenium import webdriver
import configparser
from tkinter import *
import tkinter.messagebox
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
clear = lambda: os.system('cls')
clear()
print("Initialising...")

root=Tk()
root.withdraw()
root.attributes("-topmost", True)

config = configparser.ConfigParser()
config.read_file(open(r'../config.txt'))
msg = ""
cred = 0
uname = config.get('My Section','uname')
passd = config.get('My Section','pass')

fireFoxOptions = webdriver.FirefoxOptions()
# fireFoxOptions.headless=True
# fireFoxOptions.set_headless()
# browser = webdriver.Firefox(firefox_options=fireFoxOptions)
driver = webdriver.Firefox(executable_path=r'../geckodriver.exe' , options=fireFoxOptions)

try:
    driver.get('https://latticeinnovations.greythr.com')
    clear()
    print("Loading the login page...")
    time.sleep(18)

except:
    tkinter.messagebox.showinfo('Error','Not able to reach https://latticeinnovations.greythr.com')
    driver.close()
    root.destroy()
    root.mainloop()
    sys.exit(1)

try:
    clear()
    # print('Logging in...')
    username_input = '//*[@id="username"]'
    password_input = '//*[@id="password"]'
    login_submit = '/html/body/app-root/uas-portal/div/div/main/div/section/div[1]/o-auth/section/div/app-login/section/div/div/div/form/button'
    driver.find_element_by_xpath(username_input).send_keys(uname)  # enter username here
    driver.find_element_by_xpath(password_input).send_keys(passd)  # enter password here
    driver.find_element_by_xpath(login_submit).click()
    time.sleep(1)
    
    try:
        errordiv = driver.find_element_by_xpath('/html/body/app-root/uas-portal/div/div/main/div/section/div[1]/o-auth/section/div/app-login/section/div/div/div/form/error-container/div/div/div[1]')
        cred = 1
    except Exception:
        cred = 0
        print("Logged in...")
        pass
    curl = driver.current_url.split('/')[3]
    if(cred):
        clear()
        print("Login failed, please check your credentials")
        msg = "Login failed, please check your credentials"
        tkinter.messagebox.showinfo('Error',msg)
        driver.close()
        root.destroy()
        root.mainloop()
        sys.exit(1)
    time.sleep(5)
except: 
    if(msg==""):
        print('Not able to login (error in locating input fields / login button)')
        msg = 'Not able to login (error in locating input fields / login button)'
        tkinter.messagebox.showinfo('Error',msg)
        driver.close()
        root.destroy()
        root.mainloop()
        sys.exit(1)
    sys.exit(1)

try:
    signinbtn = 'gt-button:nth-child(1)'
    clear()
    print('Looking for sign-in button...')
    animation = "|/-\\"
    idx = 0
    wait = 0
    # while (not wait):
    #     print(animation[idx % len(animation)] ,'  Looking for sign-in button...', end="\r")
    #     idx += 1
    #     time.sleep(0.2)
    WebDriverWait(driver, 25).until(EC.element_to_be_clickable((By.CSS_SELECTOR, signinbtn)))
    driver.find_element_by_css_selector(signinbtn).click()
    clear()
    print("Sign-in button clicked")
    time.sleep(3)
    driver.find_element_by_css_selector(signinbtn).click()
    print("Sign-out button clicked")
    time.sleep(2)
except:
    tkinter.messagebox.showinfo('Error','Not able to mark the attendance (sign-in button could not be located), please retry or mark the attendance manually')
    # driver.close()
    root.destroy()
    root.mainloop()
    sys.exit(1)

print('Your attendance has been marked for today')
tkinter.messagebox.showinfo('Info','Your attendance has been marked for today')
driver.close()
driver.quit()
root.destroy()
root.mainloop()
sys.exit(0)

# x = input("Attendance marked for today. Please press x to close this window")    
# if(x=='x' or x=='X'):
#     sys.exit(1)
# while(x!='x' or x!='X'):
#     x = input("Attendance marked for today. Please press x to close this window")    
#     if(x=='x' or x=='X'):
#         sys.exit(1)


