import * as XLSX from "xlsx";


const filepath = "./cypress/downloads/Dummy Data Users.xlsx";


describe("desc", () => {

  
    it('Read excel file', () => {
      cy.task('readXlsx', { file: filepath, sheet: "users_e2e" }).then((rows) => {
        // expect(rows.length).to.equal(543)
        // expect(rows[0]["column name"]).to.equal(11060)
        console.log(rows)
      })
    })

  });


