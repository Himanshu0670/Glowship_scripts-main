///<reference types = "cypress" />

import  {cyconfig} from '../../config/cyconfig'


const url = cyconfig.url
const filepath = "./cypress/downloads/Proposals.xlsx"

describe('Proposal creation', () => {
    beforeEach(() => {
      // cy.visit('https://saas.test.glowsun.io')
      cy.visit('http://localhost:4200')
      cy.get('#mat-input-0').clear();
      cy.get('#mat-input-0').type('jayant@thelattice.in');
      cy.get('#continuebtn').click();
      cy.get('#mat-input-1').clear();
      cy.get('#mat-input-1').type('password');
      cy.get('.mat-button-wrapper').click();
      cy.wait(1000)
      // cy.get('#users-nav > .nav-item > .mat-body-2').click();
      // cy.get('.mat-accent > .mat-button-wrapper').click();
      
    })

    it('create proposal for LEAD 1',() => {
    // cy.visit(url + '/user/app/main/homeowner/createview/9034674358/98' )
    cy.visit(url + '/user/app/main/homeowner/createview/9898995959/97' )

    cy.get('.mat-tab-label').eq(1).click()
    cy.get('.mat-expansion-panel').eq(0).click()
    cy.get('.mat-radio-label').filter(':contains("Existing")').eq(0).click()
    cy.contains('.mat-form-field','Monthly electricity bill').type('500')
    cy.contains('.mat-form-field','Occupants').type('4')
    cy.contains('.mat-form-field','Roof').type('500')
    cy.contains('.mat-form-field','bedrooms').type('1')
    cy.contains('.mat-form-field','Sanction').type('1')
    cy.get('.mat-radio-label').filter(':contains("First")').eq(0).click()
    cy.get('.mat-radio-label').filter(':contains("No")').eq(0).click()
    cy.get('.mat-radio-label').filter(':contains("Single Phase")').eq(0).click()
    cy.get('.mat-checkbox-label').filter(':contains("Water Pump")').eq(0).click()
    cy.get('.mat-select-value-text').filter(':contains("0.5")').eq(0).click()
    cy.get('mat-option').eq(0).click()
    cy.get('.mat-select-value-text').filter(':contains("Booster")').eq(0).click({force:true})
    cy.get('mat-option').eq(1).click()
    cy.contains('.mat-form-field','Utility').click()
    cy.contains('.mat-option-text','BEST').click()
    cy.get('.mat-raised-button').contains('Next').click()
    //Appliances ->
    cy.get('.tabContent > :nth-child(1) .mat-select ').filter(':contains("Type")').eq(0).click()
    cy.contains('.mat-option-text','Lights (Bulb)').click()
    cy.get('.tabContent > :nth-child(1) .mat-select ').filter(':contains("Power")').eq(0).click()
    cy.contains('.mat-option-text','40').click()
    cy.get('.tabContent > :nth-child(1) .mat-form-field ').filter(':contains("quantity")').eq(0).type('1')
    cy.get('.tabContent > :nth-child(1) .mat-raised-button ').click()
    // cy.contains('button','Save and Continue').click()

    });

    xit('create proposal for LEAD 2',() => {
      cy.task('readXlsx', { file: filepath, sheet: "Sheet1" }).then((data:any) => {
        // expect(rows.length).to.equal(543)
        // expect(rows[0]["column name"]).to.equal(11060)
        console.log("DATA FROM PROPOSALS XLSX",data)
        let lights = data[0].lights.split("&")
        console.log(lights);
        console.log(lights[0].split(":"));
        console.log(lights[1].split(":"));
        console.log(lights[2].split(":"));
        console.log(lights[3].split(":"));
        
air_con: 2
appliances: "geysers:1,AC:1"
bedrooms: 2
comm: 2
construction: "Existing"
fans: "Regular:2,BLDC:1,Pedestal:1,Table:1"
kitchen: "Refrigerators 165 Ltrs : 1"
laptops: 2
lights: "Lights (Bulb):60 Watts#3&Lights (CFL):5 Watts#3&Lights (LED):5 Watts#3&Tubelights:T-12 #3"
monthly_ebill: 1000
non_essential: 2
occupants: 5
roof_area: 1500
sanctioned_load: 3
server: 2
terrace: "Second"
tv: "LED 30 inch : 1"
ups: "Yes"
utility_comp: "BEST"
water_pump: 2
water_pump_geninfo: "Borewell Submersible Pump,0.75 hp\r\n"
let el = data[0]
      cy.visit(url + '/user/app/main/homeowner/createview/9898995959/97' )
      cy.get('.mat-tab-label').eq(1).click()
      cy.get('.mat-expansion-panel').eq(0).click()
      cy.get('.mat-radio-label').filter(':contains("construction")').eq(el.construction).click()
      cy.contains('.mat-form-field','Monthly electricity bill').type(el.monthly_ebill)
      cy.contains('.mat-form-field','Occupants').type(el.occupants)
      cy.contains('.mat-form-field','Roof').type(el.roof_area)
      cy.contains('.mat-form-field','bedrooms').type(el.bedrooms)
      cy.contains('.mat-form-field','Utility').click()
      cy.contains('.mat-option-text',el.utility_comp).click()
      cy.contains('.mat-form-field','Sanction').type(el.sanctioned_load)
      // cy.get('.mat-radio-label').filter(':contains("' + el.terrace + '")').eq(0).click()
      cy.get('.mat-radio-label').filter(`:contains("${el.terrace}")`).eq(0).click()
      cy.get('.mat-radio-label').filter(`:contains("${el.ups}")`).eq(0).click()
      cy.get('.mat-radio-label').filter(`:contains("${el.supply}")`).eq(0).click()
    let appliances =  el.appliances.split(',')
    appliances.forEach((element:any) => {
      let name = element.split(':')[0]
      let qty = element.split(':')[1]
      cy.contains('.mat-checkbox-label',name).click()
      cy.contains('[fxflex="40"] .mat-select','1').last().click()
      cy.contains('.mat-option-text',qty).click()
    });
    if(el.water_pump_geninfo){
      let pump = el.water_pump_geninfo.split(',')[0]
      let hp = el.water_pump_geninfo.split(',')[1]
      cy.contains('.mat-checkbox-label','Water').click()
      cy.get('.mat-select-value-text').filter(`:contains("Booster")`).eq(0).click({force:true})
      cy.contains('.mat-option-text',pump).click()
      cy.get('.mat-select-value-text').filter(`:contains("0.5")`).eq(0).click({force:true})
      cy.contains('.mat-option',hp).click()
    }
    cy.get('.mat-raised-button').contains('Next').click()

   
     //Appliances ->
      // cy.get('.tabContent > :nth-child(1) .mat-select ').filter(':contains("Type")').eq(0).click()
      // cy.contains('.mat-option-text','Lights (Bulb)').click()
      // cy.get('.tabContent > :nth-child(1) .mat-select ').filter(':contains("Power")').eq(0).click()
      // cy.contains('.mat-option-text','40').click()
      // cy.get('.tabContent > :nth-child(1) .mat-form-field ').filter(':contains("quantity")').eq(0).type('1')
      // cy.get('.tabContent > :nth-child(1) .mat-raised-button ').click()
      // cy.contains('button','Save and Continue').click()
     
      })
     
     
      });
  

});

function getnthchild(item:any){
      switch(item){
        case 'Geysers': return ' [style="width: 100%;"] > :nth-child(1) '
          
      }
      return null
}