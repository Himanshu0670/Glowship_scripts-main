/// <reference types="cypress" />
// const fs = require('fs')


import { writeFileSync } from "fs";
import * as XLSX from "xlsx";
import { environment }  from '../../../src/environments/environment'

// const XLSX = require('xlsx')

var url = "DummyDataUsers.xlsx";
const apiendpoint = environment.api_endpoint;
const filepath = "./cypress/downloads/Dummy Data Users.xlsx";
let worksheets = {};

describe('example to-do app', () => {
  beforeEach(() => {
    // cy.visit('https://saas.test.glowsun.io')
    cy.visit('http://localhost:4200')
    cy.get('#mat-input-0').clear();
    cy.get('#mat-input-0').type('jayant@thelattice.in');
    cy.get('#continuebtn').click();
    cy.get('#mat-input-1').clear();
    cy.get('#mat-input-1').type('password');
    cy.get('.mat-button-wrapper').click();
    // cy.get('#users-nav > .nav-item > .mat-body-2').click();
    // cy.get('.mat-accent > .mat-button-wrapper').click();
    
  })

xit('app user',() => {
  cy.get('#users-nav > .nav-item > .mat-body-2').click();
  cy.get('div.ng-star-inserted > .mat-accent').click();
  cy.get('#role').click()
  cy.get('.mat-option').contains('Mobile').click()
  cy.get('#companySalesRadio').click()
  // cy.get('mat-form-field').eq(1).click().type('fullname')
  cy.contains('mat-form-field','Full').find('input').type('full name')
  cy.contains('mat-form-field','Email').find('input').type('full name')
  cy.get('[formControlName=mobile]').type('5566556656')
  // cy.get('mat-form-field').filter(':contains("Mobile")').eq(1).type('5566556656')
  // cy.contains('mat-form-field','Mobile').and('not.have.text',"Mobile app user").find('input').type('full name')
  // cy.get('mat-form-field').should('contain.text','Mobile').find('input').type('1231231')
  
  cy.contains('button','SAVE').should('be.disabled')
  // cy.get('[fxlayoutalign="space-between start"] > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
  
 });

  xit('csv to json',() => {
  
    cy.fixture('users_e2e.csv').then((data) => {
        cy.task('csvToJson', data).then((data:any) => {
          data = data.slice(4,data.length-1)
          let api = apiendpoint + '/user'
          console.log("the data from csv",data);
          
    cy.intercept('POST',api,(req) => {
      req.continue((res : any) => {
        console.log(res.body.message);
        expect((res.body.message) == "User created successfuly." ||
        (res.body.message) == "Email id already exists." ||
        (res.body.message) == "Mobile number already exists." 
        )
      })
    })

  data.forEach((element:any) => {
   if(element.user_type!=''){
      cy.get('#users-nav > .nav-item > .mat-body-2').click();
      cy.get('.mat-accent > .mat-button-wrapper').click();
      cy.get('#role').click();
      cy.get('mat-option').contains(element.role).click(); 
      cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click()
      cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
      cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').clear();
      cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type(element.fname);
      cy.get(':nth-child(3) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').clear();
      if(element.mobile){
        cy.get(':nth-child(3) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type(element.mobile);
      }
      cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
      cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').clear();
      if(element.email){
        cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type(element.email);
      } 
      if(element.notify==0){
        cy.get('.mat-checkbox-inner-container').click()
        }
        // cy.get('button.mat-raised-button').contains("SAVE").should("be.focused")
        cy.get("#companySalesRadio").click()
        // cy.get('.right-card > [fxlayout="column"] > :nth-child(2)  input ').type(element.add_line1);
        cy.get('.right-card mat-form-field [formControlName=address_line_1] ').type(element.add_line1);
        cy.get('.right-card > [fxlayout="column"] > :nth-child(3)  input').type(element.add_line2);
        cy.get('.right-card > [fxlayout="column"] > :nth-child(4)  input ').type(element.add_line3);
        cy.get('.right-card > [fxlayout="column"] > :nth-child(5)  input').type(element.city);
        cy.get('.right-card mat-select').click();
        cy.get("mat-option").contains(element.state).click();
        cy.get('.right-card > [fxlayout="column"] > :nth-child(6)  input ').type(element.pincode);
        cy.get('#savebtn').should("not.be.disabled")
        cy.get('button.mat-raised-button').contains("SAVE").click()


      }
  else{
        cy.get('#users-nav > .nav-item > .mat-body-2').click();
        cy.get('.mat-accent > .mat-button-wrapper').click();
        cy.get('#role').click();
        cy.get('mat-option').contains(element.role).click(); 
        cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click()
        cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
        cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').clear();
        cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type(element.fname);
        cy.get(':nth-child(3) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').clear();
      if(element.mobile){
        cy.get(':nth-child(3) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type(element.mobile);
      }
      cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
      cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').clear();
      if(element.email){
        cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type(element.email);
      }
      if(element.notify==0){
        cy.get('.mat-checkbox-inner-container').click()
      }
      cy.get('#savebtn').should("not.be.disabled")
      cy.get('button.mat-raised-button').contains("SAVE").click()
      // cy.get('button.mat-button.mat-primary').eq(8).should('not.be.disabled')
    }

   });


  })
 })
});


it.only('Read excel file', () => {
  cy.task('readXlsx', { file: filepath, sheet: "users_e2e" }).then((data:any) => {
    // expect(rows.length).to.equal(543)
    // expect(rows[0]["column name"]).to.equal(11060)
    // data = data.slice(4,5)
    console.log(data)

    data.forEach((element:any) => {
      if(element.user_type && element.user_type==1){
         cy.get('#users-nav > .nav-item > .mat-body-2').click();
         cy.get('.mat-accent > .mat-button-wrapper').click();
         cy.get('#role').click();
         cy.get('mat-option').contains(element.role).click(); 
         cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click()
         cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
         cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').clear();
         cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type(element.fname);
         cy.get(':nth-child(3) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').clear();
         if(element.mobile){
           cy.get(':nth-child(3) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type(element.mobile);
         }
         cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
         cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').clear();
         if(element.email){
           cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type(element.email);
         } 
         if(element.notify==0){
           cy.get('.mat-checkbox-inner-container').click()
           }
           // cy.get('button.mat-raised-button').contains("SAVE").should("be.focused")
           cy.get("#companySalesRadio").click()
           // cy.get('.right-card > [fxlayout="column"] > :nth-child(2)  input ').type(element.add_line1);
           cy.get('.right-card mat-form-field [formControlName=address_line_1] ').type(element.add_line1);
           cy.get('.right-card > [fxlayout="column"] > :nth-child(3)  input').type(element.add_line2);
           cy.get('.right-card > [fxlayout="column"] > :nth-child(4)  input ').type(element.add_line3);
           cy.get('.right-card > [fxlayout="column"] > :nth-child(5)  input').type(element.city);
           cy.get('.right-card mat-select').click();
           cy.get("mat-option").contains(element.state).click();
           cy.get('.right-card > [fxlayout="column"] > :nth-child(6)  input ').type(element.pincode);
           cy.get('#savebtn').should("not.be.disabled")
           cy.get('button.mat-raised-button').contains("SAVE").click()
           cy.get('#add-paid-account > div > :nth-child(1)').click()
   
         }
     else{
           cy.get('#users-nav > .nav-item > .mat-body-2').click();
           cy.get('.mat-accent > .mat-button-wrapper').click();
           cy.get('#role').click();
           cy.get('mat-option').contains(element.role).click(); 
           cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click()
           cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
           cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').clear();
           cy.get(':nth-child(2) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type(element.fname);
           cy.get(':nth-child(3) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').clear();
         if(element.mobile){
           cy.get(':nth-child(3) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type(element.mobile);
         }
         cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
         cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').clear();
         if(element.email){
           cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type(element.email);
         }
         if(element.notify==0){
           cy.get('.mat-checkbox-inner-container').click()
         }
         cy.get('#savebtn').should("not.be.disabled")
         cy.get('button.mat-raised-button').contains("SAVE").click()
         // cy.get('button.mat-button.mat-primary').eq(8).should('not.be.disabled')
       }
   
      });
   
  })
})
})
  