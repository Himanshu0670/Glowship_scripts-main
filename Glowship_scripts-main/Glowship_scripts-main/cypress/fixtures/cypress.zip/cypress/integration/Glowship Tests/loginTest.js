/// <reference types="cypress" />

// Welcome to Cypress!
//
// This spec file contains a variety of sample tests
// for a todo list app that are designed to demonstrate
// the power of writing tests in Cypress.
//
// To learn more about how Cypress works and
// what makes it such an awesome testing tool,
// please read our getting started guide:
// https://on.cypress.io/introduction-to-cypress

describe('example to-do app', () => {
  beforeEach(() => {
    // Cypress starts out with a blank slate for each test
    // so we must tell it to visit our website with the `cy.visit()` command.
    // Since we want to visit the same URL at the start of all our tests,
    // we include it in our beforeEach function so that it runs before each test
    // cy.visit('https://saas.test.glowsun.io')
    cy.visit('http://localhost:4200')
    cy.get('#mat-input-0').clear();
    cy.get('#mat-input-0').type('admintest@glowsun.io');
    cy.get('#continuebtn').click();
    cy.get('#mat-input-1').clear();
    cy.get('#mat-input-1').type('password');
    cy.get('.mat-button-wrapper').click();
  })

  /* ==== Test Created with Cypress Studio ==== */
  xit('UserCreationAdmin', function() {
    /* ==== Generated with Cypress Studio ==== */
    cy.get('#users-nav > .nav-item').click();
    cy.get('.mat-accent > .mat-button-wrapper').click();
    cy.get('[fxlayoutalign="space-between start"] > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
    cy.get('#mat-option-11 > .mat-option-text').click();
    cy.get('#mat-input-3').clear();
    cy.get('#mat-input-3').type('CypressUser');
    cy.get(':nth-child(3) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
    cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
    cy.get('#mat-input-5').clear();
    cy.get('#mat-input-5').type('cypress@us.er');
    cy.get('.mat-checkbox-inner-container').click();
    cy.get('#mat-checkbox-1-input').uncheck();
    cy.get('.mat-accent > .mat-button-wrapper').click();
    /* ==== End Cypress Studio ==== */
  });

   /* ==== Test Created with Cypress Studio ==== */
   it('UserCreationAdmin', function() {
    /* ==== Generated with Cypress Studio ==== */
    cy.get('#users-nav > .nav-item').click();
    cy.get('.mat-accent > .mat-button-wrapper').click();
    cy.get('[fxlayoutalign="space-between start"] > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
    cy.get('#mat-option-11 > .mat-option-text').click();
    cy.get('#mat-input-3').clear();
    cy.get('#mat-input-3').click();
    cy.get(':nth-child(3) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
    cy.get(':nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click();
    cy.get('#mat-input-5').clear();
    cy.get('#mat-input-5').type('cypress@us.er');
    cy.get('.mat-checkbox-inner-container').click();
    cy.get('#mat-checkbox-1-input').uncheck();
    cy.get('.mat-accent > .mat-button-wrapper').click();
    /* ==== End Cypress Studio ==== */
  });


})
  