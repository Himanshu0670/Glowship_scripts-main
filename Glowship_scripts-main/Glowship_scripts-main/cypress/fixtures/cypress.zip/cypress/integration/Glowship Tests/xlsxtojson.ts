/// <reference types="cypress" />

import * as XLSX from "xlsx";


const filepath = "./cypress/downloads/DummyData.xlsx";


describe("desc", () => {

  
    it('Read excel file', () => {
      cy.task('readXlsx', { file: filepath, sheet: "Sheet1" }).then((data:any) => {
        // expect(rows.length).to.equal(543)
        // expect(rows[0]["column name"]).to.equal(11060)
        console.log(data)
        let lights = data[0].lights.split('&');
        let fans = data[0].fans.split(',')

        lights.forEach(element => {
          // element= element.split
          // element = element.Replace('\r\n','')
        let name = element.split(',')[0].replace('\r\n','')
        let power = element.split(',')[1].replace('\r\n','')
        let qty = element.split(',')[2].replace('\r\n','')
          let arr = []
          arr.push(name,power,qty)
        console.log(arr);
        });

        fans.forEach(element => {
            console.log(element)
            let name = element.split(":")[0].replace('\r\n','')
            let qty = element.split(":")[1].replace('\r\n','')
            let arr = []
            arr.push({name:name,qty:qty})
            console.log(arr);
        });

      })
    })

  });


