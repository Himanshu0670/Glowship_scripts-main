/// <reference types="cypress" />

// Welcome to Cypress!
//
// This spec file contains a variety of sample tests
// for a todo list app that are designed to demonstrate
// the power of writing tests in Cypress.
//
// To learn more about how Cypress works and
// what makes it such an awesome testing tool,
// please read our getting started guide:
// https://on.cypress.io/introduction-to-cypress

describe('example to-do app', () => {
  beforeEach(() => {
    // Cypress starts out with a blank slate for each test
    // so we must tell it to visit our website with the `cy.visit()` command.
    // Since we want to visit the same URL at the start of all our tests,
    // we include it in our beforeEach function so that it runs before each test
    // cy.visit('https://saas.test.glowsun.io')
    cy.visit('http://localhost:4200')
   
  })

  xit('Incorrect Email',() => {
    cy.get('#mat-input-0').clear();
    cy.get('#mat-input-0').type('admintest@glowsun.io');
    cy.get('#continuebtn').click();
  });

  /* ==== Test Created with Cypress Studio ==== */
  xit('Email not found', function() {
    /* ==== Generated with Cypress Studio ==== */
    cy.get('#mat-input-0').clear();
    cy.get('#mat-input-0').type('admintest@glowsun.io');
    cy.get('.mat-button-wrapper > span').click();
    cy.get('#mat-error').should('have.text', 'Email address does not exist in the system. Please contact your administrator');
    /* ==== End Cypress Studio ==== */
  });


  /* ==== Test Created with Cypress Studio ==== */
  it('Email address does not exist in the system', function() {
    /* ==== Generated with Cypress Studio ==== */
    cy.get('#mat-input-0').clear();
    cy.get('#mat-input-0').type('admintest@glowsun.io');
    cy.get('.mat-button-wrapper > span').click();
    cy.get('#err3').should('have.id', 'err3');
    cy.get('#err3').should('have.text', ' Email address does not exist in the system. Please contact your administrator ');
    /* ==== End Cypress Studio ==== */
  });

  let email = 'admintest@glowsun.io'

  it('Email address does not exist in the system ', function() {
    /* ==== Generated with Cypress Studio ==== */
    cy.get('#mat-input-0').clear();
    cy.get('#mat-input-0').type('admintest@glowsun.io');
    cy.get('.mat-button-wrapper > span').click();
    cy.get('#err3').should('have.id', 'err3');
    cy.get('#err3').should('have.text', ' Email address does not exist in the system. Please contact your administrator ');
    /* ==== End Cypress Studio ==== */
    
  });



})
    