export const cyconfig = {
    testurl : 'https://saas.test.glowsun.io',
    localhost : 'http://localhost:4200',
    url:'http://localhost:4200'
}